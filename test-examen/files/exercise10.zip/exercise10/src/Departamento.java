import java.io.Serializable;

public class Departamento implements Serializable {
    static int codigoActual = 0;
    int codigo;
    String nombre;

    public Departamento(String nombre) {
        this.codigoActual++;
        this.codigo = codigoActual;
        this.nombre = nombre;
    }

}
