import java.io.Serializable;

public class Persona implements Serializable {
    static int codigoActual = 0;
    int codigo;
    String nombre;

    public Persona(String nombre) {
        this.codigoActual++;
        this.codigo = codigoActual;
        this.nombre = nombre;
    }

}
